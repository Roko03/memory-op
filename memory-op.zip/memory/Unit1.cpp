//---------------------------------------------------------------------------

#include <fmx.h>
#pragma hdrstop

#include <algorithm>
#include <vector>
#include <string>

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.fmx"
TForm1 *Form1;

class Card{
public:
	int value;
	bool isOpen;

	Card(int value,bool isOpen) {
		this->value = value;
		this->isOpen = isOpen;
	};
};


Card* card1 = new Card(1, false);
Card* card2 = new Card(1, false);
Card* card3 = new Card(2,false);
Card* card4 = new Card(2,false);
Card* card5 = new Card(3,false);
Card* card6 = new Card(3,false);
Card* card7 = new Card(4,false);
Card* card8 = new Card(4,false);
Card* card9 = new Card(5,false);
Card* card10 = new Card(5,false);

std::vector<Card*> arr = {card1,card2,card3,card4,card5,card6,card7,card8,card9,card10};
std::vector<Card*> picks;
std::vector<TButton*> buttons;

//---------------------------------------------------------------------------
void __fastcall TForm1::CheckCards(){
	Card* pickCard1 = picks[0];
	Card* pickCard2 = picks[1];

	auto it1 = std::find(arr.begin(), arr.end(), pickCard1);
	auto it2 = std::find(arr.begin(), arr.end(), pickCard2);

    if (it1 != arr.end() && it2 != arr.end())
	{
		int index1 = std::distance(arr.begin(), it1);
		int index2 = std::distance(arr.begin(), it2);

		if(pickCard1->value != pickCard2->value){
        	PicksField->Text = "No-Match";
			(*it1)->isOpen = false;
			(*it2)->isOpen = false;
			 buttons[index1]->Text = "";
             buttons[index2]->Text = "";
		}else{
			PicksField->Text = "Match";
			buttons[index1]->Enabled = false;
			buttons[index2]->Enabled = false;
		}
	}

	picks.clear();
}

//---------------------------------------------------------------------------
void __fastcall TForm1::ButtonClick(TObject *Sender)
{
    PicksField->Text = "";
	TButton *clickedButton = dynamic_cast<TButton*>(Sender);
	int index = clickedButton->Index - 1;

	Card* clickedCard = arr[index];
	clickedCard->isOpen = true;
	clickedButton->Text = clickedCard->value;

    picks.push_back(clickedCard);

	if(picks.size() == 2){
        CheckCards();
	}
}

//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
	: TForm(Owner)
{

	std::random_shuffle(arr.begin(),arr.end());

	int length = arr.size();
	int rows = (length > 10) ? 3 : 2;
	int buttonsPerRow = length / rows;

	buttonsContainer->Align = TAlignLayout::Center;

	for(int i=0;i<length;i++){
		TButton *button = new TButton(buttonsContainer);
		button->Parent = buttonsContainer;

		int row = i / buttonsPerRow;
		int col = i % buttonsPerRow;

		button->Height = 50;
		button->Width = 50;

		button->Position->X = col * 60;
		button->Position->Y = row * 60;

		button->OnClick = ButtonClick;

		button->Tag = i;
        buttons.push_back(button);
	}

	buttonsContainer->Width = buttonsPerRow * 60;
	buttonsContainer->Height = rows * 60;
}

//---------------------------------------------------------------------------

